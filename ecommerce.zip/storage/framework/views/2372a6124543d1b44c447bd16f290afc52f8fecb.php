    <?php $__env->startSection('content'); ?>

    <div class="container pt-3 col-md-8">




            <h3 class="into-sub-title">Faq</h3>
            <p>To give you a smooth experience we have listed possible frequently asked question. If you have any question besides these feel free to contact with us.</p>

            <div class="accordion accordion-group" id="our-values-accordion">


                <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('all')): ?>
                <span> <form method="POST" action="<?php echo e(url('faq').'/'.$faq->id); ?>" id="delete-form-<?php echo e($faq->id); ?>" style="display: none;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                  </form>
                  <a href="#" class="delete-icon-link ml-2 text-danger" data-record-id="<?php echo e($faq->id); ?>">
                    <i class="fas fa-trash delete-icon"></i>
                  </a></span><?php endif; ?>
                <div class="card">
                    <div class="card-header p-0 bg-transparent" id="heading<?php echo e($faq->id); ?>">
                        <h2 class="mb-0">
                          <button class="btn btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapse<?php echo e($faq->id); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($faq->id); ?>">
                              <?php echo e($faq->title); ?>

                          </button>
                        </h2>
                    </div>
                    <div id="collapse<?php echo e($faq->id); ?>" class="collapse" aria-labelledby="heading<?php echo e($faq->id); ?>" data-parent="#our-values-accordion">
                        <div class="card-body">
                            <?php echo e($faq->description); ?>

                        </div>
                    </div>
                  </div>



                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!--/ Accordion end -->

          </div><!-- Col end --><br/><a href="<?php echo e(url('faq/create')); ?>">
<button class="btn btn-secondary">Add FAQ</button></a>

<script>
    var deleteLinks = document.querySelectorAll('.delete-icon-link');

    deleteLinks.forEach(function(link) {
      link.addEventListener('click', function(event) {
        event.preventDefault();
        var recordId = link.getAttribute('data-record-id');
        var confirmDelete = confirm('Are you sure you want to delete this record?');

        if (confirmDelete) {
          var formId = 'delete-form-' + recordId;
          var form = document.getElementById(formId);
          form.submit();
        }
      });
    });
  </script>

    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-main\ecommerce\resources\views/livewire/faq.blade.php ENDPATH**/ ?>
    <?php $__env->startSection('content'); ?>

    <div class="container pt-3">
    <div class="row justify-content-around py-3">
        <div class="col-10 col-md-6 col-lg-5">

            <div class="card">
            <div class="card-header">
                <h3 class="card-title">Register</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="<?php echo e(route('register')); ?>" method="post">
                <?php echo csrf_field(); ?>

                <div class="card-body">
                  <div class="form-group">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="name" value="<?php echo e(old('name')); ?>" required>
                  </div>

                  <div class="form-group">
                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="mobile">Mobile</label>
                    <input type="text" class="form-control" id="mobile" name="mobile" placeholder="mobile" value="<?php echo e(old('mobile')); ?>" required>
                  </div>

                  <div class="form-group">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="email">Email</label>
                    <input type="text" class="form-control" name="email" id="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required>
                  </div>

                  <div class="form-group">
                    <?php $__errorArgs = ['referCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="referCode">Refer code</label>
                    <input type="text" class="form-control" id="referCode" name="referCode" placeholder="Enter refer code" value="<?php echo e(old('referCode')); ?>" required>
                  </div>

                  <div class="form-group">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="password">Password</label>
                    <input type="text" class="form-control" name="password" id="password" required>
                  </div>

                  <div class="form-group">
                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="password_confirmation">Confirm password</label>
                    <input type="text" class="form-control" name="password_confirmation" id="password_confirmation" required>
                  </div>

               <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Register</button>
                  <span class="refer" style="cursor:pointer; margin-left:6px">don't have a refer code?</span>
                  <span class="code d-none" style="cursor:pointer; margin-left:6px">use 1 as refer code</span>
                </div>
              </form>
            </div>
        </div>


        </div>
    </div>
</div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-main\ecommerce\resources\views/livewire/register.blade.php ENDPATH**/ ?>
    <?php $__env->startSection('content'); ?>

<div class="container pt-3" style="min-height: 100vh">
    <div class="row justify-content-around py-3">
        <div class="col-10 col-md-8 col-lg-6">

            <div class="card">
            <?php if(session()->has('status')): ?>
            <div class="text-danger">
                <?php echo e($status); ?>

            </div>
        <?php endif; ?>


            <div class="card-header">
                <h3 class="card-title">Edit payment information</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="<?php echo e(url('paymentInfo/1')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>

                <div class="card-body">
                  <div class="form-group">
                    <?php $__errorArgs = ['method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="method">Payment method</label>
                    <input type="text" class="form-control" name="method" id="method"  value="<?php echo e($paymentInfo->method); ?>" required>
                  </div>





                  <div class="form-group">
                    <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="number">number</label>
                    <textarea class="form-control" name="number" id="number" rows="5"><?php echo e($paymentInfo->number); ?></textarea required>
                  </div>


               <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Create</button>


                </div>
              </form>
            </div>
        </div>
            </div>


        </div>
    </div>



    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-main\ecommerce\resources\views/livewire/paymentedit.blade.php ENDPATH**/ ?>
    <?php $__env->startSection('content'); ?>

    <div class="container py-3">


        <div class="d-flex justify-content-center">

            <!-- Small boxesffffffffffffffffffffffffffffffffffffffffffffffffff (Stat box) -->


        <div class="card card-primary col-md-8">

        <?php if(session()->has('success')): ?>
        <p class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

        </p>
        <?php endif; ?>
              <div class="card-header">
                <h3 class="card-title">Create a course</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="<?php echo e(url('/academic')); ?>" method="post" >
                <?php echo csrf_field(); ?>


                <div class="card-body">


                      <div class="form-group">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="Name">Course Name</label>
                        <input type="text" class="form-control" id="Name" name="name" placeholder="Course Name" value="<?php echo e(old('name')); ?>" required>
                      </div>

                  <div class="form-group">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="title">Course Title</label>
                    <input type="text" class="form-control" id="title" name="title" placeholder="Title" value="<?php echo e(old('title')); ?>" required>
                  </div>

                  <div class="form-group">
                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="price">Course price</label>
                    <input type="text" class="form-control" id="title" name="price" placeholder="price" value="<?php echo e(old('price')); ?>" required>
                  </div>



                  <div class="form-group">
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="description">Course description</label>
                    <textarea class="form-control" name="description" id="description" rows="3"></textarea value="<?php echo e(old('description')); ?>" required>
                  </div>




                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Publish</button>
                </div>
              </form>


<!-- /.card-hefffffffffffffffffffffffffffffffffffffff sddddddddddddddddddd wsader -->
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-main\ecommerce\resources\views/livewire/academicCreate.blade.php ENDPATH**/ ?>
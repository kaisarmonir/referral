    <?php $__env->startSection('content'); ?>

<div class="container pt-3" style="min-height: 100vh">
    <div class="row justify-content-around py-3">
        <div class="col-10 col-md-6 col-lg-5 col-xl-4">

            <div class="card">
            <?php if(session()->has('status')): ?>
            <div class="text-danger">
                <?php echo e($status); ?>

            </div>
        <?php endif; ?>


            <div class="card-header">
                <h3 class="card-title">Login</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="<?php echo e(route('login')); ?>" method="post">
                <?php echo csrf_field(); ?>


                <div class="card-body">
                  <div class="form-group">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="email">Email</label>
                    <input type="text" class="form-control" name="email" id="email"  value="<?php echo e(old('email')); ?>" required>
                  </div>



                  <div class="form-group">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="password">Password</label>
                    <input type="text" class="form-control" name="password" id="password"  required>
                  </div>


                  <div class="form-check">
                    <input type="checkbox" class="form-check-input"  id="remember_me" >
                    <label class="form-check-label" id="remember_me" name="remember" for="remember_me">Remember me</label>
                  </div>

               <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Login</button>

                  <span style="cursor:pointer; margin-left:12px"><a href="/register">Register Now</a></span>
                </div>
              </form>
            </div>
        </div>
            </div>


        </div>
    </div>



    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-main\ecommerce\resources\views/livewire/login.blade.php ENDPATH**/ ?>
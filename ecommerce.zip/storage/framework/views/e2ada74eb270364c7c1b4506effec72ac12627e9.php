    <?php $__env->startSection('content'); ?>

    <div class="container py-3">

            <div class="d-flex justify-content-center">

    <!-- Small boxesffffffffffffffffffffffffffffffffffffffffffffffffff (Stat box) -->

<div class="card card-primary col-md-8">


<?php if(session()->has('success')): ?>
<p class="alert alert-success">
<?php echo e(session()->get('success')); ?>

</p>
<?php endif; ?>


      <div class="card-header">
        <h3 class="card-title">Edit Notice</h3>
      </div>
      <!-- /.card-header -->
      <!-- form start -->
      <form action="<?php echo e(url('order').'/'.$order->id); ?>" method="post" >
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>


        <div class="card-body">


  <div class="form-group">
            <?php $__errorArgs = ['notice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <label for="description">Notice</label>
            <textarea class="form-control" name="notice" id="notice" rows="5"><?php echo e($order->notice); ?></textarea required>
          </div>


        </div>
        <!-- /.card-body -->

        <div class="card-footer">
          <button type="submit" class="btn btn-primary">Save change</button>
        </div>
      </form>
    </div>
    <!-- /.card -->


<!-- /.card-hefffffffffffffffffffffffffffffffffffffff sddddddddddddddddddd wsader -->


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-main\ecommerce\resources\views/livewire/notice.blade.php ENDPATH**/ ?>
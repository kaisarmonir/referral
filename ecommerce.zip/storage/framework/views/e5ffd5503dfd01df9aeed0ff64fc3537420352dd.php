    <?php $__env->startSection('content'); ?>

    <div class="container pt-3">



<a href="<?php echo e(url('admin')); ?>" class="text-primary">Go back to admin dashboard</a>
        <div class="" style="text-align: center">
            <br>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($error); ?><br/>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<form id="myForm" method="post" action="<?php echo e(url('bonus').'/'.$bonus->id); ?>">
<?php echo csrf_field(); ?>
<?php echo method_field('patch'); ?>

<label for="numberField">First gen commition:</label>
<input type="number" id="numberField" placeholder="First gen" value="<?php echo e($bonus->f); ?>" name="f" required>% <br>
<label for="numberFiel">Second gen commition:</label>
<input type="number" id="numberFiel" placeholder="Second gen" value="<?php echo e($bonus->s); ?>" name="s" required>% <br>
<label for="numberFie">Third gen commition:</label>
<input type="number" id="numberFie" placeholder="Third gen" value="<?php echo e($bonus->t); ?>" name="t" required>% <br>
<br>
<input type="submit" value="Change">
</form>
</div>


      <!--  <script src="https://www.youtube.com/iframe_api"></script>

            <div id="player"></div>
            <script>
              // Replace 'YOUR_VIDEO_ID' with the actual YouTube video ID
              var videoId = 'TmRgK-pXH9c';
              var player;

              function onYouTubeIframeAPIReady() {
                player = new YT.Player('player', {
                  height: '360',
                  width: '640',
                  videoId: videoId,
                  events: {
                    'onReady': onPlayerReady,
                    'onStateChange': onPlayerStateChange
                  }
                });
              }

              function onPlayerReady(event) {
                event.target.playVideo();
              }

              var startTime;
              function onPlayerStateChange(event) {
                if (event.data == YT.PlayerState.PLAYING) {
                  startTime = new Date().getTime();
                } else if (event.data == YT.PlayerState.PAUSED || event.data == YT.PlayerState.ENDED) {
                  var endTime = new Date().getTime();
                  var duration = Math.floor((endTime - startTime) / 1000);
                  console.log('Video duration:', duration, 'seconds');
                  alert(duration);
                }
              }
            </script>
        -->


    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-main\ecommerce\resources\views/livewire/pay.blade.php ENDPATH**/ ?>
    <?php $__env->startSection('content'); ?>

    <div class="container pt-3">



<a href="<?php echo e(url('admin')); ?>" class="text-primary">Go back to admin dashboard</a>
        <div class="" style="text-align: center">
            <div style="text-align: ">



                Name:<?php echo e($user->name); ?> <br>
                Mobile:<?php echo e($user->mobile); ?> <br>
                Refer code:<?php echo e($earning->user_id); ?> <br>
                Total earning:<?php echo e($earning->firstGen+$earning->secondGen+$earning->thirdGen); ?> <br>
                Total withdraw:<?php echo e($earning->withdraw); ?>

            </div> <br> <br>
<form id="myForm" method="post" action="<?php echo e(url('earning').'/'.$earning->id); ?>">
<?php echo csrf_field(); ?>
<?php echo method_field('patch'); ?>

<label for="numberField">Withdraw Now:</label>
<input type="number" id="numberField" placeholder="Enter amount" name="withdraw" required>
<br>
<input type="submit" value="Withdraw">
</form>
</div>


      <!--  <script src="https://www.youtube.com/iframe_api"></script>

            <div id="player"></div>
            <script>
              // Replace 'YOUR_VIDEO_ID' with the actual YouTube video ID
              var videoId = 'TmRgK-pXH9c';
              var player;

              function onYouTubeIframeAPIReady() {
                player = new YT.Player('player', {
                  height: '360',
                  width: '640',
                  videoId: videoId,
                  events: {
                    'onReady': onPlayerReady,
                    'onStateChange': onPlayerStateChange
                  }
                });
              }

              function onPlayerReady(event) {
                event.target.playVideo();
              }

              var startTime;
              function onPlayerStateChange(event) {
                if (event.data == YT.PlayerState.PLAYING) {
                  startTime = new Date().getTime();
                } else if (event.data == YT.PlayerState.PAUSED || event.data == YT.PlayerState.ENDED) {
                  var endTime = new Date().getTime();
                  var duration = Math.floor((endTime - startTime) / 1000);
                  console.log('Video duration:', duration, 'seconds');
                  alert(duration);
                }
              }
            </script>
        -->


    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-main\ecommerce\resources\views/livewire/earning.blade.php ENDPATH**/ ?>